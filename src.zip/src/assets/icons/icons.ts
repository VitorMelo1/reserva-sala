import DashboardIcon from "./Dashboard.png";
import ReservasIcon from "./Reservas.png";
import RelatoriosIcon from "./Relatorios.png";
import ExitIcon from "./exit.png";
import IconUni from "./IconUni.png";
import LogoUni from "../LogoUni2.png"; // Importando a logo

export { DashboardIcon, ReservasIcon, RelatoriosIcon, ExitIcon, IconUni, LogoUni };
