import React from 'react';

const Relatorios: React.FC = () => {
    return (
        <div>
            <h1>Relatórios</h1>
            <p>Bem-vindo à página de relatórios.</p>
        </div>
    );
};

export default Relatorios;