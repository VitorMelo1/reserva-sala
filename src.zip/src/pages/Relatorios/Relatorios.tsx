import React from "react";

const Relatorios: React.FC = () => {
  return (
    <div>
      <h1>Relatórios</h1>
      <p>Em construção...</p>
    </div>
  );
};

export default Relatorios;