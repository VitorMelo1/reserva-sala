const Reserva = () => {
    return <h1>Página de Reservas</h1>;
  };
  
  export default Reserva;
  