import React, { useState } from "react";
import style from "./Reserva.module.scss";
import Header from "../../layouts/Header/Header";

const Reservas: React.FC = () => {
  const [bloco, setBloco] = useState("A");
  const [sala, setSala] = useState("");
  const [data, setData] = useState("");
  const [hora, setHora] = useState("");
  const [reservas, setReservas] = useState<any[]>([]);

  const handleReservar = () => {
    const novaReserva = { bloco, sala, data, hora };
    setReservas([...reservas, novaReserva]);
    setSala("");
    setData("");
    setHora("");
  };

  return (
    <div className={style.reservas_container}>
      <Header
        titulo="Reservar Sala"
        subtitulo="Agende uma sala conforme a disponibilidade."
      />

      <div className={style.formulario}>
        <div>
          <label>Bloco:</label>
          <select value={bloco} onChange={(e) => setBloco(e.target.value)}>
            <option value="A">Bloco A</option>
            <option value="B">Bloco B</option>
          </select>
        </div>
        <div>
          <label>Nome da Sala:</label>
          <input
            type="text"
            value={sala}
            onChange={(e) => setSala(e.target.value)}
            placeholder="Ex: Sala 101"
          />
        </div>
        <div>
          <label>Data:</label>
          <input
            type="date"
            value={data}
            onChange={(e) => setData(e.target.value)}
          />
        </div>
        <div>
          <label>Hora:</label>
          <input
            type="time"
            value={hora}
            onChange={(e) => setHora(e.target.value)}
          />
        </div>
        <button onClick={handleReservar}>Reservar</button>
      </div>

      <div className={style.lista_reservas}>
        <h2>Reservas Feitas</h2>
        {reservas.length === 0 ? (
          <p>Nenhuma reserva registrada.</p>
        ) : (
          <ul>
            {reservas.map((res, index) => (
              <li key={index}>
                {res.sala} - Bloco {res.bloco} - {res.data} às {res.hora}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default Reservas;
