import React from "react";
import styles from "./Dashboard.module.scss"; 

const Dashboard = () => {
    return <h1>Página de Dashboard</h1>;
};

export default Dashboard;
